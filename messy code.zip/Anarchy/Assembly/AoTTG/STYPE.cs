﻿public enum STYPE
{
    BILLBOARD,
    BILLBOARD_SELF,
    XZ
}