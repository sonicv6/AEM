﻿public enum BottomType
{
    Die,
    Teleport
}