﻿public enum HintType
{
    MOVE,
    TELE,
    CAMA,
    JUMP,
    JUMP2,
    HOOK,
    HOOK2,
    SUPPLY,
    DODGE,
    ATTACK
}