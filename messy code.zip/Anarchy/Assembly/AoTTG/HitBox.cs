﻿using UnityEngine;

public class HitBox : MonoBehaviour
{
    public Group group;
    public Vector3 hitPosition;
    public float multiple = 1f;
}