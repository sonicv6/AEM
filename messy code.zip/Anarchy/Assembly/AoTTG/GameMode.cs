﻿public enum GameMode
{
    KillTitan,
    PvpAhss,
    EndlessTitan,
    SurviveMode,
    BossFightCT,
    Trost,
    Tutorial,
    RACING,
    PVP_CAPTURE,
    None
}