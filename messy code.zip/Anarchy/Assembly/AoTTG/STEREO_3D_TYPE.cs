﻿public enum STEREO_3D_TYPE
{
    MONO,
    SIDE_BY_SIDE,
    OCULUS
}