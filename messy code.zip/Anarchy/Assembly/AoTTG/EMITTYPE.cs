﻿public enum EMITTYPE
{
    POINT,
    BOX,
    SPHERE,
    CIRCLE,
    LINE
}