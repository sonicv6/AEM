﻿using UnityEngine;

public class FengColor
{
    public static Color dawnAmbientLight = new Color(0.345f, 0.305f, 0.271f);
    public static Color dawnLight = new Color(0.729f, 0.643f, 0.458f);
    public static Color dayAmbientLight = new Color(0.494f, 0.478f, 0.447f);

    public static Color dayLight = new Color(1f, 1f, 1f);

    public static Color hairPunk1 = new Color(0.45f, 1f, 0f);
    public static Color hairPunk2 = new Color(1f, 0.95f, 0f);
    public static Color hairPunk3 = new Color(1f, 0.1f, 0.05f);
    public static Color nightAmbientLight = new Color(0.05f, 0.05f, 0.05f);

    public static Color nightLight = new Color(0.08f, 0.08f, 0.1f);
    public static Color titanSkin1 = new Color(0.97f, 0.94f, 0.92f);

    public static Color titanSkin2 = new Color(0.91f, 0.89f, 0.82f);

    public static Color titanSkin3 = new Color(0.89f, 0.81f, 0.76f);
}