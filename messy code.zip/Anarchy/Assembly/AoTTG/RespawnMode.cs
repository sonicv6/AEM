﻿public enum RespawnMode
{
    NEVER,
    DEATHMATCH,
    NEWROUND
}