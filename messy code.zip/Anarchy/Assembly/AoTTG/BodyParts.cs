﻿public enum BodyParts
{
    UPPER,
    ARM_L,
    ARM_R,
    LOWER
}