﻿public class ColorSet
{
    public static string color_A = "FAAC58";
    public static string color_B = "F4FA58";
    public static string color_C = "ACFA58";
    public static string color_D = "FFFFFF";
    public static string color_human = "A9D0F5";
    public static string color_human_1 = "82FA58";
    public static string color_human_2 = "9A2EFE";
    public static string color_red = "FE2E2E";
    public static string color_S = "FA8258";
    public static string color_SS = "BE81F7";
    public static string color_SSS = "FF0000";
    public static string color_system = "F3F781";
    public static string color_titan_player = "F5DA81";
    public static string color_titans = "FA8258";
    public static string color_X = "000000";
}