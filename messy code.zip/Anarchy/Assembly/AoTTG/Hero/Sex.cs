﻿public enum Sex
{
    Male,
    Female
}