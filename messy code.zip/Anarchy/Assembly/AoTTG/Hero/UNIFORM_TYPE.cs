﻿public enum UNIFORM_TYPE
{
    UniformA,
    UniformB,
    CasualA,
    CasualB,
    CasualAHSS
}