﻿public enum CreatePart
{
    Sex,
    Eye,
    Face,
    Glass,
    Hair,
    Skin,
    Costume,
    Cape,
    Division,
    Preset
}