﻿public enum DIVISION
{
    TraineesSquad,
    TheSurveryCorps,
    TheGarrison,
    TheMilitaryPolice
}