﻿public enum CreateStat
{
    SPD,
    GAS,
    BLA,
    ACL,
    Skill
}