﻿public enum CameraType
{
    ORIGINAL,
    WOW,
    TPS,
    NewTPS
}