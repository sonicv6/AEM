﻿public enum Buff
{
    NoBuff,
    SpeedUp
}