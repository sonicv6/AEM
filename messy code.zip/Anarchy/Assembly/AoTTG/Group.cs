﻿public enum Group
{
    H,
    T,
    A
}