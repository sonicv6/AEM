﻿public enum CheckPointState
{
    Non,
    Human,
    Titan
}