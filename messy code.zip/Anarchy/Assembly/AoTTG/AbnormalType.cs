﻿public enum AbnormalType
{
    Normal,
    Aberrant,
    Jumper,
    Crawler,
    Punk
}