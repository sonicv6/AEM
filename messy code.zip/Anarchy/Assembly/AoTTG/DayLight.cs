﻿public enum DayLight
{
    Day,
    Dawn,
    Night
}