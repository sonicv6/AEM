﻿public class RacingResult
{
    public readonly string Name;
    public readonly float Time;

    public RacingResult(string name, float time)
    {
        Name = name;
        Time = time;
    }
}