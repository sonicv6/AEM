﻿using UnityEngine;

public class ButtonTextEffect : MonoBehaviour
{
    private void Start()
    {
    }

    private void Update()
    {
    }
}