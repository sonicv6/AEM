﻿using UnityEngine;

public class EnemyfxIDcontainer : MonoBehaviour
{
    public int myOwnerViewID = -1;
    public string titanName;
}