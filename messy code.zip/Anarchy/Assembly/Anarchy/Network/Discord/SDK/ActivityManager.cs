﻿namespace Anarchy.Network.Discord.SDK
{
    public partial class ActivityManager
    {
        public void RegisterCommand()
        {
            RegisterCommand(null);
        }
    }
}
