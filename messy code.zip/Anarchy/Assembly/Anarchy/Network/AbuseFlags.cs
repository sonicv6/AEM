﻿namespace Anarchy.Network
{
    /// <summary>
    /// Flags for Anarchy functions that could be counted as abusive
    /// </summary>
    public enum AbuseFlags : int
    {
        InfiniteGasInPvp = 0b1
    }
}
