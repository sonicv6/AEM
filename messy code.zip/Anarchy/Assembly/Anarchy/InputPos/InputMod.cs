﻿
namespace Anarchy.InputPos
{
    internal enum InputMod : int
    {
        CleanChat,
        CleanConsole,
        DebugPanel,
        StatsPanel
    }
}
