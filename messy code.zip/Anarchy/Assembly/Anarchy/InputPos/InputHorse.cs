﻿namespace Anarchy.InputPos
{
    internal enum InputHorse : int
    {
        HorseForward,
        HorseBackward,
        HorseLeft,
        HorseRight,
        HorseWalk,
        HorseJump,
        HorseMount
    }
}