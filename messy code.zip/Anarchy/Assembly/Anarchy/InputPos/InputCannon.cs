﻿namespace Anarchy.InputPos
{
    internal enum InputCannon : int
    {
        CannonUp,
        CannonDown,
        CannonLeft,
        CannonRight,
        CannonFire,
        CannonMount,
        CannonSlow,
    }
}