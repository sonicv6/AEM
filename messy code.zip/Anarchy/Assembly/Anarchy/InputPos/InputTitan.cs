﻿namespace Anarchy.InputPos
{
    internal enum InputTitan : int
    {
        TitanForward,
        TitanBackward,
        TitanLeft,
        TitanRight,
        TitanJump,
        TitanKill,
        TitanWalk,
        TitanPunch,
        TitanSlam,
        TitanGrabFront,
        TitanGrabBack,
        TitanGrabNape,
        TitanSlap,
        TitanBite,
        TitanCoverNape,
        TitanSit,
    }
}