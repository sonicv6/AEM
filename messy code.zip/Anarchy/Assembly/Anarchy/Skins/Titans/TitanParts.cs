﻿namespace Anarchy.Skins.Titans
{
    public enum TitanParts
    {
        Eye,
        Hair,
        Body
    }
}