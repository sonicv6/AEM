﻿namespace Anarchy.Skins.Humans
{
    public enum HumanParts : int
    {
        Horse = 0,
        Hair,
        Eyes,
        Glass,
        Face,
        Skin,
        Costume,
        Cape,
        Left3DMG,
        Right3DMG,
        Gas,
        Hoodie,
        WeaponTrail
    }
}