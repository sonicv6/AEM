﻿namespace Anarchy.Custom.Scripts
{
    public enum TrapType
    {
        GasUsage,
        Kill,
        Both
    }
}
