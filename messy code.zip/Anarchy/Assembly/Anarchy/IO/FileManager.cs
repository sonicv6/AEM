﻿namespace Anarchy.IO
{
    //TODO:
    internal class FileManager
    {
    }
}