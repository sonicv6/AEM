﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Anarchy.IO
{
    public class Style
    {
        //TODO
    }
}
