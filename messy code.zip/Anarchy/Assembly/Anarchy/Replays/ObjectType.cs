﻿namespace Anarchy.Replays
{
    public enum ObjectType : byte
    {
        Byte,
        Short,
        Integer,
        Long,
        Float,
        Double,
        Vector3,
        Quaternion
    }
}
