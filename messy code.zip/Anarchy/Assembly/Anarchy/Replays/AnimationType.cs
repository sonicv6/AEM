﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Anarchy.Replays
{
    public enum AnimationType : byte
    {
        Play,
        PlayAt,
        CrossFade
    }
}
