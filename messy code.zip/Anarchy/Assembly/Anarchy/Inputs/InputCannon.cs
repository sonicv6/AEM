﻿namespace Anarchy.Inputs
{
    internal enum InputCannon : int
    {
        CannonUp,
        CannonDown,
        CannonLeft,
        CannonRight,
        CannonFire,
        CannonMount,
        CannonSlow,
    }
}