﻿namespace Anarchy.Inputs
{
    internal enum InputRebinds : int
    {
        ReelIn,
        ReelOut,
        GasBurst,
        MinimapMax,
        MinimapToggle,
        MinimapReset,
        OpenChat,
        LiveSpectate
    }
}