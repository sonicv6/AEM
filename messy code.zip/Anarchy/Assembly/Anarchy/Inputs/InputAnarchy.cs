﻿namespace Anarchy.Inputs
{
    internal enum InputAnarchy
    {
        Restart = 0,
        Pause = 1,
        DebugPanel = 2,
        ChatHistoryPanel = 3,
        StatsPanel = 4
    }
}