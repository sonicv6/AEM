﻿namespace Anarchy.Inputs
{
    internal enum InputHorse : int
    {
        HorseForward,
        HorseBackward,
        HorseLeft,
        HorseRight,
        HorseWalk,
        HorseJump,
        HorseMount
    }
}