﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Anarchy.UI
{
    public class CreditsPanel
    {
        //TODO
        //Feng credits
        //Aottg-2 team for hosting photon
        //Anarchy team
        //Anarchy testers?
        //Helped modders
    }
}
