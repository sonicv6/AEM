﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Anarchy.UI
{
    public class ReplaysPanel
    {
        //TODO
    }
}
