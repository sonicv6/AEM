﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Anarchy.UI.Render
{
    //TODO: This is GUI for character creation menu
    public class CustomCharacterCreationGUI : GUIBase
    {
        public CustomCharacterCreationGUI() : base(nameof(CustomCharacterCreationGUI))
        {

        }

        protected internal override void Draw()
        {
            //TODO:
            throw new NotImplementedException();
        }
    }
}
