﻿namespace Anarchy.UI
{
    public enum ElementType
    {
        Box,
        Button,
        SelectionGrid,
        Slider,
        SliderBody,
        TextField,
        Toggle
    }
}