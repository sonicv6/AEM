﻿namespace NGUI
{
    public enum Direction
    {
        Reverse = -1,
        Toggle,
        Forward
    }
}