﻿namespace NGUI
{
    public enum EnableCondition
    {
        DoNothing,
        EnableThenPlay
    }
}