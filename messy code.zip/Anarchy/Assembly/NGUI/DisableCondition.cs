﻿namespace NGUI
{
    public enum DisableCondition
    {
        DisableAfterReverse = -1,
        DoNotDisable,
        DisableAfterForward
    }
}