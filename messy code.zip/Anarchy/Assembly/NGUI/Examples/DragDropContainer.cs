﻿using UnityEngine;

[AddComponentMenu("NGUI/Examples/Drag and Drop Container")]
public class DragDropContainer : MonoBehaviour
{
}