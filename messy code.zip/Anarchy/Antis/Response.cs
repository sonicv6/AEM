﻿namespace Antis
{
    public delegate void Response(int ID, bool ban, string reason);
}