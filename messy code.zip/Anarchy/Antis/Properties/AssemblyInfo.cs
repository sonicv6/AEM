﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: CompilationRelaxations(CompilationRelaxations.NoStringInterning)]
[assembly: AssemblyTitle("Antis")]
[assembly: AssemblyDescription("Designed for AoTTG Game by Feng Lee")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Fate Grand Order co")]
[assembly: AssemblyProduct("Antis")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: ComVisible(false)]
[assembly: Guid("61ae834a-671a-4599-b3ca-80aa69f145fc")]
[assembly: AssemblyVersion("0.7.7.0")]
[assembly: AssemblyFileVersion("0.7.7.0")]